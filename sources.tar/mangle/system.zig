//* The definition and implementations of systems<br>
//* A system requires:
//*     - `requirements: Signature`
//*     - `process: fn` and/or `receive: fn`
//* In order to qualify

const std = @import("std");
const meta = std.meta;
const util = @import("util.zig");
const flags = @import("flags.zig");
const StructField = std.builtin.Type.StructField;
const StructAttrs = std.builtin.Type.StructField.Attributes;

const Argument = struct {
    @"comptime": bool,
    type: ?type,
};

/// Defines required fields used in system.qualifies
pub const fields = struct {
    /// Name and type of the processing function of the system
    pub const process = struct {
        pub const name = "process";
        /// Should be read as
        /// ```zig
        /// fn (comptime T: type, _: *T, _: *const RegistryInformation) Error!void`
        /// ```
        pub const fields: []const Argument = &.{
            .{
                .@"comptime" = true,
                .type = type,
            },
            .{
                .@"comptime" = false,
                .type = null,
            },
            .{
                .@"comptime" = false,
                .type = null,
            },
        };
    };

    /// Name and type of the event function of the system
    pub const receive = struct {
        pub const name = "receive";

        /// Should be read as
        /// ```zig
        /// fn (comptime T: type, value: *T, event: anytype, registry_info: *RegistryInformation) Error!void`
        /// ```
        pub const fields: []const Argument = &.{
            .{
                .@"comptime" = true,
                .type = type,
            },
            .{
                .@"comptime" = false,
                .type = null,
            },
            .{
                .@"comptime" = false,
                .type = null,
            },
            .{
                .@"comptime" = false,
                .type = null,
            },
        };
    };

    /// Name and type of the signature of the system
    pub const signature = struct {
        pub const name = "requirements";
        pub const Type = Signature;
    };
};

pub const Signature = struct {
    /// Used to represent a signature requirement
    pub const Item = struct {
        /// Used to filter qualifications
        type: type,

        /// Used for systems to use dot syntax access
        /// Ignored in qualifications
        /// See, also [NamedType](#mangled.system.Signature.NamedType)
        name: []const u8,
    };

    /// Requirements
    fields: []const Item,

    /// returns whether or not a structure (if not structure returns whether or not it is contained)
    /// qualifies for the signature
    pub inline fn qualifies(comptime self: Signature, comptime T: type) bool {
        comptime {
            const info = switch (@typeInfo(flags.Flatten(T))) {
                .@"struct" => |i| i,
                else => @compileError("Error, type '" ++ @typeName(T) ++ "' is not a struct!"),
            };

            for (self.fields) |requirement| {
                const U = switch (@typeInfo(requirement.type)) {
                    .@"struct" => flags.Flatten(requirement.type),
                    else => requirement.type,
                };
                for (info.fields) |field| {
                    switch (flags.fieldFlag(field.type)) {
                        .composed => unreachable,
                        else => {
                            const Original = if (flags.isPathed(field.type)) flags.OriginalType(field.type) else field.type;
                            switch (flags.fieldFlag(requirement.type)) {
                                .owned => {
                                    if (U == Original or flags.Leaf(U) == Original) {
                                        break;
                                    }
                                },
                                .leaf => {
                                    if (U == Original) {
                                        break;
                                    }
                                },
                                .dissolve => {
                                    if (U == Original) {
                                        break;
                                    }
                                },
                                .composed => unreachable,
                            }
                        },
                    }
                } else {
                    return false;
                }
            }
            return true;
        }
    }

    /// Given a structure type `T` generates a signature from it.
    pub fn fromStruct(comptime T: type) Signature {
        comptime {
            const info = switch (@typeInfo(T)) {
                .@"struct" => |i| i,
                else => @compileError("Error: Type '" ++ @typeName(T) ++ "' is not a struct!"),
            };
            var collectFields: [info.fields.len]Item = undefined;
            for (info.fields, 0..) |value, i| {
                collectFields[i] = .{ .name = value.name, .type = value.type };
            }
            return .{ .fields = &collectFields };
        }
    }

    const voidValue: void = void{};

    /// Returns the inputed structure with names according to the fields
    ///
    ///> **NOTE**:
    ///> - `self.NamedType(T) != T` when `self.qualifies(T)` and `self.fields.len > 0`
    ///> - Asserts `self.qualifies(T)`
    ///> - Returns a memory equivilent type to T
    pub inline fn NamedType(comptime self: Signature, comptime T: type) type {
        comptime {
            var info = util.deStruct(T);
            if (!self.qualifies(T)) @compileError("Error, type '" ++ @typeName(T) ++ "' does not qualify!");
            field: for (self.fields) |field| {
                const Flattened = switch (@typeInfo(field.type)) {
                    .@"struct" => flags.Flatten(field.type),
                    else => field.type,
                };
                for (info.fieldTypes, 0..) |U, i| {
                    const Original = if (flags.isPathed(U)) flags.OriginalType(U) else U;
                    switch (flags.fieldFlag(Original)) {
                        .dissolve => {
                            if (Original == Flattened) {
                                info.fieldNames[i] = field.name;
                                info.fieldTypes[i] = flags.AliasType(U);
                                info.fieldAttributes[i].default_value_ptr = null;
                                continue :field;
                            }
                        },
                        .leaf, .owned => {
                            if (Original == Flattened) {
                                info.fieldNames[i] = field.name;
                                info.fieldTypes[i] = field.type;
                                continue :field;
                            }
                        },
                        else => unreachable,
                    }
                }
            }
            return info.Construct();
        }
    }
};

/// Checks whether the inputed system type qualifies according to `fields`
pub fn qualifies(comptime System: type) bool {
    comptime {
        switch (@typeInfo(System)) {
            .@"struct" => {
                const hasProc = hasProcess(System);
                const hasreceive = hasReceive(System);
                if (!(hasProc or hasreceive)) return false;
                for (&.{ .{ hasProc, fields.process }, .{ hasreceive, fields.receive } }) |value| {
                    const has, const func = value;
                    if (!has) continue;
                    const funcInfo = switch (@typeInfo(@TypeOf(@field(System, func.name)))) {
                        .@"fn" => |i| i,
                        else => return false,
                    };
                    outer: for (funcInfo.params) |param| {
                        for (func.fields) |arg| {
                            if (param.type == arg.type and param.is_generic == (arg.type == null))
                                continue :outer;
                        } else return false;
                    }
                }
                if (@hasDecl(System, fields.signature.name)) {
                    if (@TypeOf(@field(System, fields.signature.name)) != fields.signature.Type)
                        return false;
                } else return false;
                return true;
            },
            else => return false,
        }
    }
}

pub inline fn hasReceive(comptime Sys: type) bool {
    comptime {
        return @hasDecl(Sys, fields.receive.name);
    }
}

pub inline fn hasProcess(comptime Sys: type) bool {
    comptime {
        return @hasDecl(Sys, fields.process.name);
    }
}
