//! The mangle library is a processing engine structured around metadata tags, structure recomposition, comptime processing, and field matching.
//!
//! It contains the following namespaces, divided conceptually:
//!     - [flags](#mangle.flags), behavior & relationship flags, brought up a namespace for ergonomic's sake
//!     - [util](#mangle.util), underlying utilities
//!     - [system](#mangle.system) systems and qualifications
//!
//! It's hosted [here](https://github.com/maningreen/mangle.zig), with documentation [here](https://maningreen.github.io/mangle.zig)

const std = @import("std");
const meta = std.meta;
pub const util = @import("util.zig");
const StructField = std.builtin.Type.StructField;
const StructAttrs = std.lang.Type.Struct.FieldAttributes;
pub const flags = @import("flags.zig");
pub const Compose = flags.Compose;
pub const Leaf = flags.Leaf;
pub const Own = flags.Own;
pub const Alias = flags.Alias;
pub const alias = flags.alias;
pub const system = @import("system.zig");
pub const Array = std.ArrayList;

test {
    std.testing.refAllDecls(@This());
    std.testing.refAllDecls(flags);
    std.testing.refAllDecls(util);
    std.testing.refAllDecls(system);
}

fn applySystem(
    comptime Sys: type,
    comptime T: type,
    comptime function: std.meta.DeclEnum(Sys),
    value: *T,
    extraArgs: anytype,
) !void {
    const info = switch (@typeInfo(T)) {
        .@"struct" => |i| i,
        else => @compileError("Error: Type '" ++ @typeName(T) ++ "' is not a struct!"),
    };

    inline for (info.field_names, info.field_types, comptime flags.getFieldFlags(T)) |name, U, flag| {
        switch (@typeInfo(U)) {
            .@"struct" => {
                switch (comptime flag) {
                    .owned => {
                        switch (@typeInfo(U)) {
                            .@"struct" => {
                                try applySystem(
                                    Sys,
                                    U,
                                    function,
                                    &@field(value, name),
                                    extraArgs,
                                );
                            },
                            else => {},
                        }
                    },
                    .leaf, .dissolve => continue,
                    else => @compileError("Flag '" ++ @tagName(flag) ++ "' found present during runtime!"),
                }
            },
            else => continue,
        }
    }

    if (comptime !@field(Sys, system.fields.signature.name).qualifies(T)) return;

    const Named = @field(Sys, system.fields.signature.name).NamedType(T);
    comptime {
        if (!util.layoutEql(T, Named))
            @compileError(
                \\This is asserted, and if fails, report on github. Also include the type definition for '
            ++ @typeName(flags.OriginalType(T)) ++
                \\' and substructures." You may also want to include the definition for the system '
            ++ @typeName(Sys) ++
                \\'
                \\ this is *probably* not your fault, as the function used for this isn't perfect.
            );
    }
    return @call(
        .auto,
        @field(Sys, @tagName(function)),
        .{ Named, @as(*Named, @ptrCast(value)) } ++ extraArgs,
    );
}

fn getTypeIsLegal(comptime T: type) bool {
    const info = switch (@typeInfo(T)) {
        .@"struct" => |i| i,
        else => util.typeError(T, .@"struct"),
    };

    for (info.field_names, info.field_types, info.field_attrs, flags.getFieldFlags(T)) |name, U, attr, flag| {
        switch (@typeInfo(U)) {
            .@"struct" => {
                if (attr.@"comptime") {
                    switch (flag) {
                        // illegal behavior
                        .owned, .composed => |tag| {
                            @compileError("type '" ++ @typeName(T) ++ "' has a field ('" ++ name ++ "') which is comptime and marked as " ++ @tagName(tag) ++ ", illegal behavior");
                        },
                        else => {},
                    }
                }
                if (!getTypeIsLegal(U)) return false;
            },
            else => continue,
        }
    } else return true;
}

fn TypeTransform(comptime T: type) type {
    return flags.Path(flags.Flatten(T));
}

fn transform(value: anytype) TypeTransform(@TypeOf(value)) {
    const flattened = flags.flatten(value);
    return flags.path(&flattened).*;
}

/// `types` should be all the types the registry will utilize at the top level,
/// `types` *will not* be infered by systems.
pub fn Registry(comptime types: []const type, comptime requestedSystems: []const type, comptime ExtraInfo: ?type) type {
    comptime {
        // create structure of arrays
        var valueTypes: [types.len]type = undefined;
        var retyped: [types.len]type = undefined;
        var dropItem: [types.len]type = @splat(Array(usize));
        for (types, 0..) |T, i| {
            _ = getTypeIsLegal(T);
            if (@typeInfo(T) != .@"struct")
                @compileError("Error: type '" ++ @typeName(T) ++ "' is not a structure!");
            retyped[i] = TypeTransform(T);
            valueTypes[i] = Array(retyped[i]);
        }

        for (requestedSystems) |System| {
            system.expectQualifies(System) catch |err| switch (err) {
                error.MissingFunction => @compileError("Error: requested system '" ++ @typeName(system) ++ "' has no decl `.receive` or `.process`!"),
                error.InvalidFunctionArguments => @compileError("Error: requested system '" ++ @typeName(system) ++ " has invalid arguments on `.receive` or `.process`!"),
                error.InvalidFunctionType => @compileError("Error: requested system '" ++ @typeName(system) ++ "' does not have a function for `.receive` or `.process`!"),
                error.MissingRequirements => @compileError("Error: requested system '" ++ @typeName(system) ++ "' does not have a decl named `.requirements`!"),
                error.InvalidRequirementType => @compileError("Error: requested system '" ++ @typeName(system) ++ "' does not have `.requirements` as a signature!"),
                error.NotStruct => @compileError("Error: requested system '" ++ @typeName(System) ++ "' is a " ++ @tagName(@typeInfo(System)) ++ " not a struct!"),
            };
            @setEvalBranchQuota(System.requirements.fields.len * types.len * 500);
        }

        const DataType = @Tuple(&valueTypes);
        const AppendType = DataType;
        const DropType = @Tuple(&dropItem);

        return struct {
            /// the raw data of all the types, a tuple of @This().array
            /// recommended to not access manually
            data: DataType,
            /// The information provided to every system
            info: RegistryInformation,
            /// The items to append
            appendQueue: AppendType,
            /// The items to drop
            dropQueue: DropType,

            pub fn init(io: std.Io, gpa: std.mem.Allocator, extra: if (ExtraInfo) |T| T else void) @This() {
                var data: DataType = undefined;
                var dropVal: DropType = undefined;
                var appendVal: AppendType = undefined;
                inline for (arrayTypes, 0..) |T, i| {
                    data[i] = T.empty;
                    dropVal[i] = .empty;
                    appendVal[i] = .empty;
                }

                return .{
                    .data = data,
                    .appendQueue = appendVal,
                    .dropQueue = dropVal,
                    .info = .{
                        .gpa = gpa,
                        .io = io,
                        .delta = 0.0,
                        .extra = extra,
                    },
                };
            }

            /// asserts `value` is a top-level field, and a pointer
            fn itemDeinit(self: *@This(), value: anytype) void {
                const T: type = @TypeOf(value);
                const info = switch (@typeInfo(T)) {
                    .pointer => |i| i,
                    else => @compileError("Error: Type '" ++ @typeName(T) ++ "' is not a pointer!"),
                };
                const DeinitType: type = fn (comptime T: type, value: anytype, info: anytype) void;
                const i: comptime_int = comptime for (@This().allTypes, 0..) |U, i| {
                    if (U == info.child) break i;
                } else @compileError("Error: Type '" ++ @typeName(T) ++ "' is not in the registry!");
                if (comptime @hasDecl(originalTypes[i], "deinit")) {
                    if (comptime (@TypeOf(@field(originalTypes[i], "deinit")) == DeinitType))
                        originalTypes[i].deinit(info.child, value, self.info);
                } else return;
            }

            pub fn deinit(self: *@This()) void {
                inline for (0..types.len) |i| {
                    for (self.data[i].items) |*value|
                        self.itemDeinit(value);
                    self.data[i].deinit(self.info.gpa);
                    self.appendQueue[i].deinit(self.info.gpa);
                    self.dropQueue[i].deinit(self.info.gpa);
                }
            }

            /// Processes all items, and drops and appends after.
            pub fn process(self: *@This(), delta: f32) !void {
                self.info.delta = delta;
                inline for (allTypes) |T| {
                    @setEvalBranchQuota(@typeInfo(T).@"struct".field_names.len * systems.len * 100);
                    const arr = self.getArrayFromType(T);
                    inline for (systems) |Sys|
                        if (comptime system.hasProcess(Sys))
                            for (arr.items) |*value|
                                try applySystem(
                                    Sys,
                                    T,
                                    .process,
                                    value,
                                    .{&self.info},
                                );
                }
                self.drop();
                try self.append();
            }

            /// assumes that T is a used type.
            fn getArrayFromType(self: *@This(), comptime T: type) *Array(T) {
                const i = comptime for (allTypes, 0..) |J, i| {
                    if (T == J)
                        break i;
                } else @compileError("type '" ++ @typeName(T) ++ "' is not in the Registry!");
                return &self.data[i];
            }

            /// Given the registry and a value of a type in the registry, adds the value
            /// Returns a pointer to the type new value
            ///
            /// If the inputted value is a union, will do a switch, adding the active field into it.
            /// Asserts every field of the union is either a top-level value, or `void`, in which case it's ignored
            ///
            /// Works for `?T`, as well, ignoring if `value == null`
            pub fn addValue(self: *@This(), value: anytype) std.mem.Allocator.Error!void {
                switch (comptime @typeInfo(@TypeOf(value))) {
                    .@"struct" => {
                        const TPrime = @TypeOf(value);
                        inline for (allTypes, 0..) |U, i|
                            // already processed
                            if (TPrime == U)
                                return self.data[i].append(self.info.gpa, value);

                        const T = TypeTransform(TPrime);
                        const i = comptime for (allTypes, 0..) |J, i| {
                            if (T == J) break i;
                        } else @compileError("type \"" ++ @typeName(@TypeOf(value)) ++ "\" is not in the Registry!");

                        const flattened = flags.flatten(value);

                        try self.data[i].append(self.info.gpa, flags.path(&flattened).*);
                    },
                    .@"union" => try switch (value) {
                        inline else => |unwrapped| self.addValue(unwrapped),
                    },
                    .optional => if (value) |v| {
                        self.addValue(v);
                    },
                    else => @compileError("type \"" ++ @typeName(@TypeOf(value)) ++ " is not an optional, union, or struct!"),
                }
            }

            /// adds a top-level value to the registry after `process` is called
            ///
            ///> **NOTE**:
            ///>    - see also [appendDeferred](#mangle.Registry.RegistryInformation.appendDeferred)
            ///>    - see also [addValue](#mangle.Registry.addValue)
            pub fn appendDeferred(self: *@This(), value: anytype) std.mem.Allocator.Error!void {
                switch (@typeInfo(@TypeOf(value))) {
                    .@"union" => try switch (value) {
                        inline else => |unwrapped| self.addValue(unwrapped),
                    },
                    .optional => try if (value) |v| self.appendDeferred(v),
                    else => {},
                }
                const TPrime = TypeTransform(@TypeOf(value));
                inline for (@typeInfo(AppendType).@"struct".field_names, @typeInfo(AppendType).@"struct".field_types) |name, U| {
                    if (Array(TPrime) == U)
                        break try @field(self.appendQueue, name)
                            .append(self.info.gpa, transform(value));
                } else @compileError("Error: Type '" ++ @typeName(@TypeOf(value)) ++ "' is not in the registry!");
            }

            /// Removes a value in the registry. dropping is propagated upwards if value isn't top-level.
            ///
            ///> **NOTE**:
            ///>    - see also [appendDeferred](#mangle.Registry.RegistryInformation.dropDeferred)
            ///>    - `value` **must** be a pointer to a value
            pub fn dropDeferred(self: *@This(), value: anytype) std.mem.Allocator.Error!void {
                const info = switch (@typeInfo(@TypeOf(value))) {
                    .pointer => |p| p,
                    else => @compileError("Error: type '" ++ @typeName(value) ++ "' is not a pointer!"),
                };
                const T = flags.OriginalType(info.child);
                const i = comptime blk: {
                    const path = flags.getPath(info.child);
                    std.debug.assert(path.len > 0);
                    var split = std.mem.splitScalar(u8, path, flags.pathing.path_delimiter);
                    const uName = split.first();
                    for (@This().allTypes, 0..) |U, i| {
                        if (util.strEql(@typeName(flags.OriginalType(U)), uName))
                            break :blk i;
                    } else @compileError(
                        "type '" ++ @typeName(T) ++ "' is not anywhere in the registry",
                    );
                };
                try self.dropQueue[i].append(self.info.gpa, @as(*allTypes[i], @ptrCast(value)) - self.data[i].items.ptr);
            }

            /// information provided to every system as the final argument.
            const Reg = @This();
            pub const RegistryInformation = struct {
                gpa: std.mem.Allocator,
                io: std.Io,
                delta: f32,
                extra: (ExtraInfo orelse void),

                /// Adds top-level item to the registry after `process` is called.
                /// Intended for calling from systems
                ///
                ///> **NOTE**:
                ///>    - see also [appendDeferred](#mangle.Registry.appendDeferred)
                ///>    - see also [addValue](#mangle.Registry.addValue)
                pub fn appendDeferred(self: *RegistryInformation, value: anytype) std.mem.Allocator.Error!void {
                    const registry: *Reg = @fieldParentPtr("info", self);
                    return registry.appendDeferred(value);
                }

                /// Given the registry information and a pointer to a type in the registry, queues it to removal.
                /// If `value` is not owned by registry, undefined behavior.
                pub fn dropDeferred(self: *RegistryInformation, value: anytype) std.mem.Allocator.Error!void {
                    const registry: *Reg = @fieldParentPtr("info", self);
                    return registry.dropDeferred(value);
                }

                /// Emits an event to every system.
                ///
                /// **NOTE**:
                ///     - Is an interrupt, other events are processed on call
                ///     - See also, [emit](#mangle.Registry.emit)
                pub fn emit(self: *RegistryInformation, eventData: anytype) !void {
                    return @as(*Reg, @fieldParentPtr("info", self)).emit(eventData);
                }

                pub fn getItemFromIndex(self: *RegistryInformation, comptime T: type, index: usize) ?*TypeTransform(T) {
                    const registry: *Reg = @fieldParentPtr("info", self);
                    return registry.getItemFromIndex(T, index);
                }
            };

            /// Loops through the dropQueue and removes the items in the registry with a double pass
            /// invalidates pointers
            fn drop(self: *@This()) void {
                inline for (&self.dropQueue, &self.data) |*queue, *array| {
                    for (queue.items) |index| {
                        self.itemDeinit(&array.items[index]);
                    }

                    std.mem.sortUnstable(usize, queue.items, {}, (struct {
                        fn lessThan(_: void, a: usize, b: usize) bool {
                            return a < b;
                        }
                    }).lessThan);

                    array.orderedRemoveMany(queue.items);
                    queue.clearAndFree(self.info.gpa);
                }
            }

            /// Loops through the append queue and adds all items to their respective arrays
            fn append(self: *@This()) !void {
                inline for (&self.appendQueue) |*list| {
                    for (list.items) |item|
                        try self.addValue(item);
                    list.clearAndFree(self.info.gpa);
                }
            }

            // / Internal function. Loops through all systems and calls `receive` if available
            /// Emits an event to every system.
            ///
            /// **NOTE**:
            ///     - Is an interrupt, if called in `process`, the event will happen
            ///     - See also, [emit](#mangle.Registry.RegistryInformation.emit)
            pub fn emit(self: *@This(), event: anytype) !void {
                inline for (allTypes) |T| {
                    const arr = self.getArrayFromType(T);
                    @setEvalBranchQuota(@typeInfo(T).@"struct".field_names.len * systems.len * 100);
                    inline for (systems) |Sys|
                        if (comptime system.hasReceive(Sys))
                            for (arr.items) |*value|
                                try applySystem(
                                    Sys,
                                    T,
                                    .receive,
                                    value,
                                    .{ event, &self.info },
                                );
                }
            }

            /// All the systems that were requested. Includes unused systems.
            pub const systems: []const type = requestedSystems;
            /// The internal arrays used.
            pub const arrayTypes = valueTypes;
            /// The internal types used.
            pub const allTypes = retyped;
            /// The original types inputted to the system.
            pub const originalTypes: []const type = types;

            /// Prints the systems top-level types & owned fields qualify for.
            ///
            /// Runs automatically on `@import("builtin").mode == .debug`, doesn't otherwise
            pub fn logQualify() void {
                inline for (originalTypes) |T| {
                    printTypeQualifies(T, @typeName(T));
                }
            }

            fn printTypeQualifies(comptime T: type, comptime prefix: []const u8) void {
                std.debug.print("Type '{s}' qualifies for system(s): ", .{prefix});
                inline for (systems) |Sys| {
                    if (Sys.requirements.qualifies(T)) {
                        std.debug.print("'{}', ", .{Sys});
                    }
                }
                std.debug.print("\n", .{});
                inline for (@typeInfo(T).@"struct".field_types, @typeInfo(T).@"struct".field_names, comptime flags.getFieldFlags(T)) |U, name, flag| {
                    switch (flag) {
                        .owned => printTypeQualifies(U, prefix ++ "." ++ name),
                        else => {},
                    }
                }
            }

            pub fn getItemFromIndex(self: *@This(), comptime T: type, index: usize) ?*TypeTransform(T) {
                const U = TypeTransform(T);
                const arr = self.getArrayFromType(U);
                return if (index < arr.items.len) &arr.items[index] else null;
            }
        };
    }
}

test "getItemFromIndex" {
    const gpa = std.testing.allocator;
    const io = std.Io.failing;
    const T = struct { u32 };
    const Reg = Registry(&.{T}, &.{}, null);

    var reg: Reg = Reg.init(io, gpa, {});
    defer reg.deinit();
    try reg.addValue(T{0});
    try reg.addValue(T{1});
    try reg.addValue(T{2});
    try reg.addValue(T{3});
    try reg.addValue(T{4});
    try reg.addValue(T{5});

    {
        const t = reg.info.getItemFromIndex(T, 0).?;
        try std.testing.expect(t.@"0" == 0);
    }
    {
        const t = reg.info.getItemFromIndex(T, 1).?;
        try std.testing.expect(t.@"0" == 1);
    }
    {
        const t = reg.info.getItemFromIndex(T, 2).?;
        try std.testing.expect(t.@"0" == 2);
    }
    {
        const t = reg.info.getItemFromIndex(T, 3).?;
        try std.testing.expect(t.@"0" == 3);
    }
    {
        const t = reg.info.getItemFromIndex(T, 4).?;
        try std.testing.expect(t.@"0" == 4);
    }
    {
        const t = reg.info.getItemFromIndex(T, 5).?;
        try std.testing.expect(t.@"0" == 5);
    }
    {
        const t = reg.info.getItemFromIndex(T, 6);
        try std.testing.expect(t == null);
    }
}
