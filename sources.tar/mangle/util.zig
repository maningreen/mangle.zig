//* General, self-contained utilities.

const std = @import("std");

test {
    std.testing.refAllDecls(@This());
}

const paddingFmt = "__explicit_padding_{d}__";

/// Given a type, say `std.mem.Allocator`
/// return the basename of the type, in this case `Allocator`
/// > **WARNING**:
/// > - May be ambiguous for nonunique names, when being unique matters, such as indexing use `@typeName()`
pub fn getBaseName(comptime T: type) [:0]const u8 {
    comptime {
        const full_name = @typeName(T);
        // Find the last index of '.'
        if (std.mem.lastIndexOfScalar(u8, full_name, '.')) |index|
            return full_name[index + 1 ..];
        return full_name;
    }
}

/// Count represents the amount of fields
///
///> **NOTE**:
///> - Intended for use at comptime
///> [See also, deStruct](#mangle.util.deStruct)
pub fn DeStructInfo(count: comptime_int) type {
    return struct {
        pub const size = count;

        fieldAttributes: [count]std.builtin.Type.StructField.Attributes,
        fieldNames: [count][]const u8,
        fieldTypes: [count]type,

        /// Returns a new type of size `DeStructInfo(count).size + add`
        ///> **WARNING**:
        ///> - New items are `= undefined`
        pub fn expand(self: @This(), add: comptime_int) DeStructInfo(@This().size + add) {
            if (add < 0) @compileError("Error: add is < 0, cannot shrink!");
            var ret: DeStructInfo(@This().size + add) = undefined;
            for (@typeInfo(@This()).@"struct".fields) |field| {
                for (@field(self, field.name), 0..) |val, i|
                    @field(ret, field.name)[i] = val;
            }
            return ret;
        }

        /// Constructs a struct with `@Struct` according to fields
        /// [See also ConstructExtra](#mangle.util.DeStructInfo.ConstructExtra)
        pub inline fn Construct(comptime self: @This()) type {
            return self.ConstructExtra(.auto, null);
        }

        /// Constructs a struct with `@Struct` according to fields
        /// allows for extra options passed in
        /// [See also ](#mangle.Util.DeStructInfo.Construct)
        pub inline fn ConstructExtra(comptime self: @This(), layout: std.builtin.Type.ContainerLayout, backing: ?type) type {
            var defaultCount: comptime_int = 0;
            for (self.fieldAttributes) |attr| {
                if (attr.default_value_ptr) |_| defaultCount += 1;
            }

            const DefaultContainer = @Tuple(&([_]type{?*const anyopaque} ** defaultCount));
            comptime var default: DefaultContainer = undefined;
            var i = 0;
            for (self.fieldAttributes,) |attr| {
                if (attr.default_value_ptr) |ptr| {
                    default[i] = ptr;
                    i += 1;
                }
            }
            const T = struct {
                const value: DefaultContainer = default;
            };
            i = 0;
            var newAttrs: [self.fieldAttributes.len]std.builtin.Type.StructField.Attributes = undefined;
            for (self.fieldAttributes, 0..) |attr, j| {
                newAttrs[j] = attr;
                if (attr.default_value_ptr) |_| {
                    newAttrs[j].default_value_ptr = T.value[i];
                    i += 1;
                }
            }

            const Result = @Struct(layout, backing, &self.fieldNames, &self.fieldTypes, &newAttrs);
            return Result;
        }
    };
}

pub inline fn deStruct(comptime T: type) DeStructInfo(@typeInfo(T).@"struct".fields.len) {
    comptime {
        const info = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => @compileError("Error: type '" ++ @typeName(T) ++ "' is not a structure!"),
        };
        var ret: DeStructInfo(info.fields.len) = undefined;
        for (info.fields, 0..) |field, i| {
            ret.fieldAttributes[i].@"align" = field.alignment;
            ret.fieldAttributes[i].@"comptime" = field.is_comptime;
            ret.fieldAttributes[i].default_value_ptr = field.default_value_ptr;
            ret.fieldTypes[i] = field.type;
            ret.fieldNames[i] = field.name;
        }
        return ret;
    }
}

/// Sorts DeStructInfo by memory offset.
/// When constructing, it's recommended to use [ConstructExtra(.@"extern")](#mangle.util.DeStructInfo.ConstructExtra)
///
///> **NOTE**:
///> - See also [deStruct](#mangle.util.deStruct)
pub inline fn deStructLayout(comptime T: type) DeStructInfo(@typeInfo(T).@"struct".fields.len) {
    comptime {
        const info = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => @compileError("Error: type '" ++ @typeName(T) ++ "' is not a structure!"),
        };
        var fields: [info.fields.len]std.builtin.Type.StructField = undefined;
        for (0..info.fields.len) |i|
            fields[i] = info.fields[i];

        std.mem.sortUnstable(
            std.builtin.Type.StructField,
            &fields,
            void{},
            (struct {
                fn lessThan(_: void, a: std.builtin.Type.StructField, b: @TypeOf(a)) bool {
                    return @offsetOf(T, a.name) < @offsetOf(T, b.name);
                }
            }).lessThan,
        );

        var ret: DeStructInfo(fields.len) = undefined;
        var structI = 0;
        for (info.fields, 0..) |field, i| {
            ret.fieldAttributes[i].@"align" = field.alignment;
            ret.fieldAttributes[i].@"comptime" = field.is_comptime;
            ret.fieldAttributes[i].default_value_ptr = field.default_value_ptr;
            ret.fieldTypes[i] = field.type;
            ret.fieldNames[i] = field.name;

            structI += @sizeOf(@FieldType(T, field.name));
        }

        return ret;
    }
}

pub inline fn strEql(a: []const u8, b: []const u8) bool {
    return std.mem.eql(u8, a, b);
}

///goes through the fields and applies the `==` operator
///
///> **WARNING**:
///> - does not (yet) cover pointers and substructure fields
pub inline fn structEql(a: anytype, b: @TypeOf(a)) bool {
    const T = @TypeOf(a);
    std.debug.assert(@typeInfo(T) == .@"struct");
    const tInfo = comptime @typeInfo(T).@"struct";

    var eql: bool = true;
    inline for (tInfo.fields) |field|
        eql = eql and @field(a, field.name) == @field(b, field.name);
    return eql;
}

/// Given a structure and fields, decomposes the structure boundaries between them, raising sub-fields
///
///> **NOTE**:
///> - Does not account for name conflicts (sorry)
///> - Does not create a memory equivalent.
///
///> **TODO**
///> - [ ] fix: name conflicts
///
///> **COMPILE ERRORS**
///> - targets[n] is not to a sub-structure field
pub inline fn Decompose(comptime T: type, targets: []const std.meta.FieldEnum(T)) type {
    comptime {
        if (targets.len == 0) return T;
        const info = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => @compileError("Error: Type '" ++ @typeName(T) ++ "' is not a struct!"),
        };

        var newFieldCount: comptime_int = @typeInfo(T).@"struct".fields.len;
        for (targets) |target| {
            switch (@typeInfo(@FieldType(T, @tagName(target)))) {
                .@"struct" => |i| newFieldCount += i.fields.len - 1,
                else => @compileError("Error: field '" ++ @tagName(target) ++ "' on type '" ++ @typeName(T) ++ "' is not a struct!"),
            }
        }

        var reconstructed: DeStructInfo(newFieldCount) = undefined;
        var i = 0;
        for (info.fields) |field| {
            for (targets) |target| {
                if (!strEql(@tagName(target), field.name))
                    continue;
                for (@typeInfo(field.type).@"struct".fields) |subField| {
                    reconstructed.fieldTypes[i] = subField.type;
                    reconstructed.fieldNames[i] = field.name ++ "_" ++ subField.name;
                    reconstructed.fieldAttributes[i] = .{
                        .@"align" = subField.alignment,
                        .@"comptime" = subField.is_comptime,
                        .default_value_ptr = subField.default_value_ptr,
                    };
                    i += 1;
                }
                break;
            } else {
                reconstructed.fieldTypes[i] = field.type;
                reconstructed.fieldNames[i] = field.name;
                reconstructed.fieldAttributes[i] = .{
                    .@"align" = field.alignment,
                    .@"comptime" = field.is_comptime,
                    .default_value_ptr = field.default_value_ptr,
                };
                i += 1;
            }
        }

        return reconstructed.Construct();
    }
}

/// Given a value, returns a casted version to the decomposed value
///
///> **NOTE**:
///> - runtime overhead
///> - See also [Decompose](#mangle.util.Decompose)
pub inline fn decompose(
    value: anytype,
    comptime targets: []const std.meta.FieldEnum(@TypeOf(value)),
) Decompose(@TypeOf(value), targets) {
    const T = @TypeOf(value);
    const info = switch (@typeInfo(T)) {
        .@"struct" => |i| i,
        else => @compileError("Error: Type '" ++ @typeName(T) ++ "' is not a struct!"),
    };
    const Fields = std.meta.FieldEnum(T);

    var ret: Decompose(T, targets) = undefined;

    inline for (info.fields) |field| {
        const contains = comptime std.mem.containsAtLeast(Fields, targets, 1, &.{std.meta.stringToEnum(Fields, field.name).?});
        if (contains) {
            const U = field.type;

            const uInfo = switch (@typeInfo(U)) {
                .@"struct" => |i| i,
                else => @compileError("Error: field '" ++ field.name ++ "' is not a struct!"),
            };

            for (uInfo.fields) |subfield| {
                const subName = std.fmt.comptimePrint("{s}_{s}", .{ field.name, subfield.name });
                if (@hasField(T, subName))
                    @field(ret, subName) = @field(@field(value, field.name), subfield.name)
                else
                    @field(ret, subfield.name) = @field(@field(value, field.name), subfield.name);
            }
        }
    }
    return ret;
}

/// Given a string, returns an enum literal
pub inline fn strToEnum(comptime T: type, comptime str: []const u8) T {
    comptime {
        for (std.enums.values(T)) |tag| {
            if (strEql(@tagName(tag), str))
                return tag;
        } else @compileError("Tag '" ++ str ++ "' does not exist in enums '" ++ @typeName(T) ++ "'");
    }
}

/// Given an In pointer, is reinterpreted into an Element type,
///> **NOTE**:
///> - Asserts sizes and alignments are the same, otherwise a compile error will be emitted
pub inline fn PtrReinterpret(comptime In: type, comptime Element: type) type {
    comptime {
        const inInfo = switch (@typeInfo(In)) {
            .pointer => |i| i,
            else => @compileError("Error: type '" ++ @typeName(In) ++ "' is not a pointer!"),
        };
        if (@alignOf(inInfo.child) != @alignOf(Element)) @compileError("Error: alignment of '" ++ @typeName(In) ++ "' and '" ++ @typeName(Element) ++ "' differ, cannot cast!");
        if (@sizeOf(inInfo.child) != @sizeOf(Element)) @compileError("Error: size of '" ++ @typeName(In) ++ "' and '" ++ @typeName(Element) ++ "' differ, cannot cast!");
        return @Pointer(
            inInfo.size,
            .{
                .@"addrspace" = inInfo.address_space,
                .@"align" = inInfo.alignment,
                .@"allowzero" = inInfo.is_allowzero,
                .@"const" = inInfo.is_const,
                .@"volatile" = inInfo.is_volatile,
            },
            Element,
            null,
        );
    }
}

/// Given type T and U, checks if the memory layout's the same.
pub inline fn layoutEql(comptime T: type, comptime U: type) bool {
    comptime {
        // const sortedT = deStructLayout(T);
        // const sortedU = deStructLayout(U);

        return @sizeOf(T) == @sizeOf(U) and @alignOf(T) == @alignOf(U);

        // for (sortedT.fieldNames, sortedU.fieldNames) |nameT, nameU| {
        // @compileLog(std.fmt.comptimePrint("field '{s}' offset A {}, offset B {}", .{ @offsetOf(T, nameT), @offsetOf(U, nameU) }));
        // if (@offsetOf(T, nameT) != @offsetOf(U, nameU) or @FieldType(T, nameT) != @FieldType(U, nameU))
        // return false;
        // } else return true;
    }
}
