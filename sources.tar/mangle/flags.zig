//! Flags for inter-structure relations.

const std = @import("std");
const util = @import("util.zig");

/// Pathing information for structures in the registry
pub const pathing = struct {
    const pathSubField = "__internal_registry_type_path__";
    const originalSubfield = "__InternalRegistryOriginalType__";
    pub const path_delimiter = '_';
};
const formats = struct {
    pub const composed = "__internal_registry_composed_flag__";
    pub const leaf = "__internal_registry_leaf_flag__";
    pub const dissolve = "__internal_registry_dissolve_flag__";
    pub const owned = "__internal_registry_ownership_flag__";
    pub const identity = "__internal_registry_ownership_path__";

    fn isFormat(str: []const u8) bool {
        inline for (@typeInfo(formats).@"struct".decl_names) |decl| {
            if (std.mem.eql(u8, @field(formats, decl), str)) return true;
        } else return false;
    }
};

const voidValue: void = {};

/// Flags the engine uses internally
pub const Flags = enum {
    /// Default for field structures
    /// Processed by systems
    owned,

    /// Flattens the field to top level for systems
    composed,

    /// Processed as a non-recursive structure
    /// Can be used in qualification but *not* it's fields
    leaf,

    /// Intended for wrapped data types
    /// Used to differentiate types, similar to `leaf` in matching, and compose after
    /// When dissolving, must have *one* field only
    dissolve,

    /// Used for default behaviors. `leaf` for comptime fields `owned` for non-comptime.
    implicit,
};

/// used to tag a type with a metadata tag
/// metadata *must* contain no formatting
///> **WARNING**:
///> -  `ApplyMetadata(T) != T` will always be true
///> -  Declarations are lost, on ApplyMetadata(T)
///> -  Methods are lost on ApplyMetadata(T)
///
///>**TODO**:
///> -  - [ ] add format checking
///
///>**NOTE**:
///> - for a runtime version: see [applyMetadata](#mangle.flags.applyMetadata)
pub fn ApplyMetadata(comptime T: type, name: []const u8) type {
    // deconstruct T
    const info = switch (@typeInfo(T)) {
        .@"struct" => |sinfo| sinfo,
        else => util.typeError(T, .@"struct"),
    };

    // construct structure information reflecting the input
    var destructed = util.deStruct(T).expand(1);
    const i = @TypeOf(destructed).size - 1;
    destructed.fieldAttributes[i] = .{ .default_value_ptr = &voidValue };
    destructed.fieldTypes[i] = void;
    destructed.fieldNames[i] = name;

    return @Struct(
        info.layout,
        info.backing_integer,
        &destructed.fieldNames,
        &destructed.fieldTypes,
        &destructed.fieldAttributes,
    );
}

pub fn applyMetadata(value: anytype, comptime name: []const u8) ApplyMetadata(@TypeOf(value), name) {
    const T: type = @TypeOf(value);
    const Altered = ApplyMetadata(T, name);
    const info = switch (@typeInfo(T)) {
        .@"struct" => |i| i,
        else => util.typeError(T, .@"struct"),
    };

    var ret: Altered = undefined;
    std.debug.assert(@FieldType(Altered, name) == void); // if this fails, report an issue.
    @field(ret, name) = {};

    inline for (info.field_names, info.field_types) |fieldName, FieldType| {
        std.debug.assert(@FieldType(Altered, fieldName) == FieldType); // if this fails, report an issue.

        @field(ret, fieldName) = @field(value, fieldName);
    }
    return ret;
}

/// used to tag a type as a leaf
///> **WARNING**:
///> -  `Leaf(T) != T` will always be true
///> -  Declarations are lost, on Leaf(T)
///> -  Methods are lost on Leaf(T)
///
///> **NOTE**:
///> - `Leaf(T)` where `@typeInfo(T) != .@"struct"` is identity
///> -  [See also `Compose`](#mangle.flags.Compose)
///> -  For a runtime version, see [leaf](#mangle.flags.leaf)
pub fn Leaf(comptime T: type) type {
    switch (@typeInfo(T)) {
        .@"struct" => {
            if (fieldFlag(T) != .implicit)
                @compileError("Error type '" ++ @typeName(T) ++ "' Already has metadata flag!");
            return ApplyMetadata(T, formats.leaf);
        },
        else => {
            if (@typeInfo(T) != .@"struct") return T;
        },
    }
}

pub fn leaf(value: anytype) Leaf(@TypeOf(value)) {
    return applyMetadata(value, @tagName(Flags.leaf));
}

/// used to tag a type as explicit ownership (default behavior)
pub fn Own(comptime T: type) type {
    comptime {
        switch (fieldFlag(T)) {
            .owned, .composed, .leaf => @compileError("Error, type '" ++ @typeName(T) ++ "' Is already marked as" ++ @tagName(fieldFlag(T))),
            else => {},
        }
        return ApplyMetadata(T, formats.owned);
    }
}

pub fn own(value: anytype) Leaf(@TypeOf(value)) {
    return applyMetadata(value, @tagName(Flags.own));
}

/// Given a type T
/// flattens the fields of any substructure fields tagged as `flag` into their parent, in which case `Reduce(T) != T`
/// Otherwise does nothing, in which case `Reduce(T) == T`
///
///> **WARNING**:
///> -  `Reduce(T) != T` is dependent on whether or not it contains a field with `flag`!
///> -  **Declarations are not guaranteed**
///> -  **Methods are not guaranteed**
///
///> **NOTE**:
///> - [See also, `flags.reduce`](#mangle.flags.reduce) for a value cast
///
///> **TODO**:
///> - Make name conflicts discarded in preference for higher level ones, and compileError otherwise
pub fn Reduce(comptime T: type, comptime flag: Flags) type {
    comptime {
        const info = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => util.typeError(T, .@"struct"),
        };
        var deconstructed = util.deStruct(T);
        // TODO: make this account for recursion
        @setEvalBranchQuota(500 * info.field_names.len);

        for (deconstructed.fieldTypes, 0..) |V, i| {
            if (@typeInfo(V) == .@"struct") {
                deconstructed.fieldTypes[i] = Reduce(V, flag);
            }
        }

        // skip if no changes made
        for (deconstructed.fieldTypes, info.field_types) |V, U| {
            if (V != U or fieldFlag(V) == flag)
                break;
        } else return T;

        var fieldDelta: comptime_int = 0;
        var fieldPostDropCount: comptime_int = 0;
        var decomposeCount: comptime_int = 0;

        for (deconstructed.fieldTypes, 0..) |V, i| {
            // just a count pass
            if (@typeInfo(V) == .@"struct") {
                const U = deconstructed.fieldTypes[i];
                if (fieldFlag(U) == flag) {
                    // - 1 to account for flag
                    fieldDelta += @typeInfo(U).@"struct".field_names.len - 1;
                    for (@typeInfo(U).@"struct".field_names) |subField| {
                        if (isMetadata(subField)) fieldPostDropCount += 1;
                    }
                    decomposeCount += 1;
                    // flagCount += 1;
                }
            }

            // fix defaults
            if (@typeInfo(V) == .@"struct") {
                if (deconstructed.fieldAttributes[i].default_value_ptr) |p| {
                    const reducedPtr = reduce(@as(*const V, @ptrCast(@alignCast(p))).*, flag);
                    const W = struct {
                        const value: @TypeOf(reducedPtr) = reducedPtr;
                    };
                    deconstructed.fieldAttributes[i].default_value_ptr = &W.value;
                }
            }
        }

        var decomposeFields: [decomposeCount]std.meta.FieldEnum(T) = undefined;
        var i = 0;
        for (deconstructed.fieldTypes, deconstructed.fieldNames) |U, name| {
            if (fieldFlag(U) == flag) {
                decomposeFields[i] = util.strToEnum(std.meta.FieldEnum(T), name);
                i += 1;
            }
        }

        const Flattened = util.Decompose(deconstructed.Construct(), &decomposeFields);
        const flattenedInfo = util.deStruct(Flattened);
        var ret: util.DeStructInfo(@TypeOf(flattenedInfo).size - fieldPostDropCount) = undefined;
        i = 0;
        outer: for (flattenedInfo.fieldNames, flattenedInfo.fieldTypes, flattenedInfo.fieldAttributes) |name, Type, attr| {
            // drop inherited flags
            if (!isMetadata(name)) {
                const decls = @typeInfo(formats).@"struct".decl_names;
                for (decls) |decl| {
                    if (std.mem.containsAtLeast(u8, name, 1, @field(formats, decl))) {
                        continue :outer;
                    }
                }
            }

            ret.fieldAttributes[i] = attr;
            ret.fieldTypes[i] = Type;
            ret.fieldNames[i] = name;
            i += 1;
        }
        return ret.Construct();
    }
}

/// given value and flags to reduce from the type, recursed through and copies values over.
///
/// See [Reduce(T)](#mangle.flags.Reduce) for more information
pub fn reduce(value: anytype, comptime flag: Flags) Reduce(@TypeOf(value), flag) {
    const T = @TypeOf(value);
    const info = switch (@typeInfo(T)) {
        .@"struct" => |i| i,
        else => util.typeError(T, .@"struct"),
    };

    // TODO: make this account for recursion
    @setEvalBranchQuota(2000 * info.field_names.len);

    var ret: Reduce(T, flag) = undefined;
    const Return = @TypeOf(ret);
    if (T == Return)
        return value;
    inline for (info.field_names, info.field_types) |name, Type| {
        switch (@typeInfo(Type)) {
            .@"struct" => {
                if (@hasField(Return, name)) {
                    if (@FieldType(Return, name) == Type) {
                        @field(ret, name) = @field(value, name);
                    }
                } else {
                    const reduced = reduce(@field(value, name), flag);
                    if (comptime fieldFlag(Type) == flag) {
                        inline for (@typeInfo(@TypeOf(reduced)).@"struct".field_names) |subField| {
                            if (@hasField(Return, subField))
                                @field(ret, subField) = @field(reduced, subField)
                            else if (@hasField(Return, name ++ "_" ++ subField))
                                @field(ret, name ++ "_" ++ subField) = @field(reduced, subField);
                        }
                    } else @field(ret, name) = reduced;
                }
            },
            else => @field(ret, name) = @field(value, name),
        }
    }
    return ret;
}

/// Returns whether or not str is one of the flag formats
///
///> **NOTE**:
///>    - [See also flags](#mangle.flags.Flags)
///>    - When field checking, just use `fieldFlag`
pub fn isFlagFormat(str: []const u8) bool {
    inline for (std.enums.values(std.meta.DeclEnum(formats))) |decl| {
        if (std.mem.eql(u8, str, @field(formats, @tagName(decl))))
            return true;
    } else return false;
}

/// Given type T
/// Looks at fields for metadata
/// If not `@typeInfo(T) == .@"struct"`
/// returns .leaf
pub fn fieldFlag(comptime T: type) Flags {
    switch (@typeInfo(T)) {
        .@"struct" => {},
        else => return .leaf,
    }
    inline for (&.{ .leaf, .composed, .dissolve, .owned }) |flag| {
        const flagMeta = @field(formats, @tagName(flag));
        if (@hasField(T, flagMeta)) return flag;
    } else return .implicit;
}

/// Applies the `.compose` flag to a type
///
/// When processed **and matched** by systems, substructure fields are brought up to top level with [flatten](#mangle.flags.Flatten) ie:
///
/// ```zig
/// const T = struct {
///     field: Compose(U)
/// };
///
/// const U = struct {
///     x: u32
/// };
///
/// /// Flatten(T) is roughly
/// const FlattenedT = struct {
///     x: u32
/// };
/// ```
///
/// See also:
///     - [Flatten(T)](#mangle.flags.Flatten)
///     - [Flags](#mangle.flags.Flags)
///     - [Own(T)](#mangle.flags.Own)
///     - [Leaf(T)](#mangle.flags.Leaf)
pub fn Compose(comptime T: type) type {
    comptime {
        switch (fieldFlag(T)) {
            .implicit => {},
            else => @compileError("Error: type '" ++ @typeName(T) ++ "' is already flagged!"),
        }
        return ApplyMetadata(T, formats.composed);
    }
}

pub fn compose(value: anytype) Leaf(@TypeOf(value)) {
    return applyMetadata(value, @tagName(Flags.composed));
}

/// Applies the `.dissolve` flag to a type
///
/// When processed by the system **not matched**, substructure fields are brought up to top level with [flatten](#mangle.flags.Flatten) ie:
///
/// ```zig
/// const T = struct {
///     field: Dissolve(U)
/// };
///
/// const U = struct {
///     x: u32
/// };
///
/// // Erode(T) is roughly
/// const FlattenedT = struct {
///     field: u32
/// };
/// ```
///
///> **WARNING**
///> - Dissolve(T) can only be applied to structures with *one* field, otherwise there's an inherit name collision.
///
///
///> **NOTE**
///> - It's recommended that you just use [Alias(T)](#mangle.flags.Alias), this is for if mainly advanced users
///> - See also:
///>    - [Erode(T)](#mangle.flags.Erode)
///>    - [Flags](#mangle.flags.Flags)
///>    - [Own(T)](#mangle.flags.Own)
///>    - [Leaf(T)](#mangle.flags.Leaf)
///>    - [Alias(T)](#mangle.flags.Alias)
///>    - [Compose(T)](#mangle.flags.Compose)
pub fn Dissolve(comptime T: type) type {
    comptime {
        switch (fieldFlag(T)) {
            .implicit => {},
            else => |v| @compileError("Error: type '" ++ @typeName(T) ++ "' is already flagged '" ++ @tagName(fieldFlag(v))),
        }
        switch (@typeInfo(T)) {
            .@"struct" => |i| if (i.fields.len > 1) @compileError("Error: type '" ++ @typeName(T) ++ "' contains more than one field!"),
            else => {},
        }
        return ApplyMetadata(T, formats.dissolve);
    }
}

/// Given a type, creates an **unique** structure alias for systems to match to
///
/// Example:
/// ```zig
/// comptime {
///     std.debug.assert(Key != u8);
///     std.debug.assert(Key == Alias(u8, "key"));
///     std.debug.assert(Key.type == u8);
/// }
///
/// const Key = Alias(u8, "key");
/// const ShouldChange = Alias(void, "ShouldChange");
///
/// const MyType = struct {
///     key: Key // will not match with u8
///     should_change: ShouldChange // will not match with void
/// }
/// ```
///
///> **NOTE**
/// Works for any type, ensure `label` is unique.
/// `label` will be the name of the field, and is of type `T`
pub fn Alias(comptime Type: type, comptime label: []const u8) type {
    comptime {
        const T = @Struct(
            .auto,
            null,
            &.{ label, formats.dissolve },
            &.{ Type, void },
            &.{
                std.lang.Type.Struct.FieldAttributes{
                    .@"align" = null,
                    .default_value_ptr = null,
                    .@"comptime" = false,
                },
                std.lang.Type.Struct.FieldAttributes{
                    .@"align" = null,
                    .default_value_ptr = &voidValue,
                    .@"comptime" = false,
                },
            },
        );
        return T;
    }
}

/// Returns a wrapped, aliased version of `value`
///
/// Usage:
/// ```zig
/// const Position = Alias(u32, "position");
///
/// // input type to cast to, and value
/// const my_position = alias(Position, 30);
///
/// // explicit paramater initiation (depends on string inputed to `Alias`)
/// const my_position_explicit = Position{ .position = 30 };
/// ```
pub fn alias(comptime T: type, value: anytype) T {
    switch (@typeInfo(T)) {
        .@"struct" => |i| {
            var ret: T = undefined;
            @field(ret, formats.dissolve) = {};
            inline for (i.field_names) |field| {
                comptime if (util.strEql(field, formats.dissolve)) continue;
                @field(ret, field) = value;
            }
            return ret;
        },
        else => @compileError("Error: Type '" ++ @typeName(T) ++ "' is not a struct!"),
    }
}

/// Returns the original type of an aliased type
///> **NOTE**:
///>    - AliasType(Alias(T, "_")) == T
///>    - For runtime usage see [aliasUnwrap](#mangle.flags.aliasUnwrap)
pub fn AliasType(comptime T: type) type {
    comptime {
        const info = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => @compileError("Error: type '" ++ @typeName(T) ++ "' is not a struct!"),
        };
        for (info.field_names, info.field_types) |field, U| {
            if (!isMetadata(field)) return U;
        } else unreachable;
    }
}

/// Unwraps an aliased type into base type.
///
///> **NOTE**:
///>    - See also, [AliasType](#mangle.flags.AliasType)
pub fn aliasUnwrap(value: anytype) AliasType(@TypeOf(value)) {
    const info = switch (@typeInfo(@TypeOf(value))) {
        .@"struct" => |i| i,
        else => @compileError("Error: type '" ++ @typeName(@TypeOf(value)) ++ "' is not a struct!"),
    };
    inline for (info.field_names) |field|
        if (comptime !isMetadata(field))
            return @field(value, field);
}

/// Application of `Dissolve`
///
/// For more information see:
///     - [Alias(T)](#mangle.flags.Alias)
///     - [Dissolve(T)](#mangle.flags.Dissolve)
///
/// For a runtime version, see [erode](#mangle.flags.erode)
pub fn Erode(comptime T: type) type {
    comptime {
        return Reduce(T, .dissolve);
    }
}

/// Runtime application of `Dissolve`
///
/// For more information see:
///     - [Alias(T)](#mangle.flags.Alias)
///     - [Dissolve(T)](#mangle.flags.Dissolve)
///
/// For a type version, see [Erode](#mangle.flags.Erode)
pub fn erode(value: anytype) Erode(@TypeOf(value)) {
    const T = @TypeOf(value);
    const TPrime = Erode(T);
    if (util.layoutEql(T, TPrime)) {
        const copy = @as(util.PtrReinterpret(*T, TPrime), @ptrCast(&value)).*;
        return copy;
    } else {
        return reduce(value, .dissolve);
    }
}

/// Application of `Compose`
///
/// For more information see: [Compose(T)](#mangle.flags.Compose)
///
/// For a runtime version, see [flatten](#mangle.flags.flatten)
pub inline fn Flatten(comptime T: type) type {
    return Reduce(T, .composed);
}

/// Runtime application of `Compose`
///
/// For more information see: [Compose(T)](#mangle.flags.Compose)
///
/// For a type version, see [Flatten](#mangle.flags.Flatten)
pub fn flatten(value: anytype) Flatten(@TypeOf(value)) {
    return reduce(value, .composed);
}

/// Given a type `T`, if ownership is found, applies a pathing to it for runtime indexing
///
///> **NOTE**
///> - see also [path](#mangle.flags.path)
pub fn Path(comptime T: type) type {
    return PathInternal(T, "");
}

fn PathData(comptime prefix: []const u8, comptime Original: type) type {
    return struct {
        const __internal_registry_type_path__ = prefix;
        const __InternalRegistryOriginalType__ = Original;
        const __internal_registry_leaf_flag__ = {};

        const static: @This() = .{};
    };
}

fn PathInternal(comptime T: type, comptime prefix: []const u8) type {
    switch (@typeInfo(T)) {
        .@"struct" => {},
        else => return T,
    }
    if (@hasField(T, formats.identity)) {
        @compileError(std.fmt.comptimePrint(
            "Type '{}' already has a path: '{any}'. Please report this as an issue.",
            .{
                OriginalType(T),
                @typeInfo(@FieldType(T, formats.identity)).@"struct".decls,
            },
        ));
    }

    var deconstructed = util.deStruct(T);
    for (deconstructed.fieldTypes, deconstructed.fieldNames, getFieldFlags(T), 0..) |U, name, flag, i| {
        switch (flag) {
            .owned => {
                const newPrefix = prefix ++ .{pathing.path_delimiter} ++ name;
                const Pathed = PathInternal(U, newPrefix);
                deconstructed.fieldTypes[i] = Pathed;
                if (deconstructed.fieldAttributes[i].defaultValue(U)) |default| {
                    deconstructed.fieldAttributes[i].default_value_ptr = &(struct {
                        const static: Pathed = (@as(*const Pathed, @ptrCast(&default))).*;
                    }).static;
                }
            },
            else => continue,
        }
    }
    var new = deconstructed.expand(1);
    const i = deconstructed.fieldNames.len;
    new.fieldNames[i] = formats.identity;
    const Data = PathData(prefix, T);
    new.fieldTypes[i] = Data;
    new.fieldAttributes[i] = .{
        .default_value_ptr = &Data.static,
    };
    return new.Construct();
}

/// Given a pointer value, retypes it into a pathed version.
///
///> **NOTE**:
///> - See also, [Path](#mangle.flags.Path)
pub fn path(value: anytype) util.PtrReinterpret(@TypeOf(value), Path(@typeInfo(@TypeOf(value)).pointer.child)) {
    const info = switch (@typeInfo(@TypeOf(value))) {
        .pointer => |i| i,
        else => util.typeError(@TypeOf(value), .pointer),
    };
    return @as(util.PtrReinterpret(@TypeOf(value), Path(info.child)), @ptrCast(value));
}

/// Returns the type path relative to a registry top level
/// String is delimited with `.` between each parent
pub fn getPath(comptime T: type) []const u8 {
    comptime {
        _ = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => util.typeError(T, .@"struct"),
        };

        if (@hasField(T, formats.identity)) {
            return @field(@FieldType(T, formats.identity), pathing.pathSubField);
        } else @compileError("Error: '" ++ @typeName(T) ++ "' is not pathed!");
    }
}

/// Given a type `J`, which is some `Path(T)` called on it, retrieve T.
///
///> **NOTE**:
///>    - `OriginalType(Path(T)) == T`
///>    - OriginalType could be defined as the inverse path.
pub fn OriginalType(comptime T: type) type {
    switch (@typeInfo(T)) {
        .@"struct" => {},
        else => return T,
    }

    if (@hasField(T, formats.identity)) {
        return @field(
            @FieldType(T, formats.identity),
            pathing.originalSubfield,
        );
    } else return T;
}

pub fn originalType(value: anytype) OriginalType(@TypeOf(value)) {
    switch (@typeInfo(@TypeOf(value))) {
        .@"struct" => {},
        else => return value,
    }

    const T = @TypeOf(value);

    if (@hasField(T, formats.identity)) {
        const Original = @field(
            @FieldType(T, formats.identity),
            pathing.originalSubfield,
        );

        var ret: Original = undefined;
        inline for (@typeInfo(Original).@"struct".field_names) |name| {
            @field(ret, name) = @field(value, name);
        }
        return ret;
    } else return value;
}

pub fn isPathed(comptime T: type) bool {
    return comptime switch (@typeInfo(T)) {
        .@"struct" => @hasField(T, formats.identity),
        else => false,
    };
}

pub fn aliasName(comptime T: type) [:0]const u8 {
    comptime {
        const info = switch (@typeInfo(T)) {
            .@"struct" => |i| i,
            else => @compileError("Error: type '" ++ @typeName(T) ++ "' is not aliased!"),
        };
        for (info.field_names) |field| {
            if (!isMetadata(field)) return field;
        }
    }
}

fn isMetadata(str: []const u8) bool {
    inline for (@typeInfo(formats).@"struct".decl_names) |decl| {
        if (util.strEql(@field(formats, decl), str)) return true;
    } else return false;
}

/// It's asserted `getFieldFlags(T)[i] != .implicit`
/// Returns default values if it is implicit.
pub fn getFieldFlags(comptime T: type) [@typeInfo(T).@"struct".field_names.len]Flags {
    const info = switch (@typeInfo(T)) {
        .@"struct" => |t| t,
        else => util.typeError(T, .@"struct"),
    };
    var flags: [info.field_names.len]Flags = undefined;
    inline for (info.field_types, info.field_attrs, 0..) |U, attr, i| {
        lbl: switch (fieldFlag(U)) {
            inline .leaf, .dissolve, .composed, .owned => |tag| flags[i] = tag,
            .implicit => continue :lbl if (attr.@"comptime") .leaf else .owned,
        }
    }
    for (flags) |value|
        std.debug.assert(value != .implicit);
    return flags;
}

/// internal testing function
fn fieldsEql(comptime T: type, comptime U: type) ?enum { name, type } {
    const tinfo = @typeInfo(T).@"struct";
    const uinfo = @typeInfo(U).@"struct";
    const value = comptime for (tinfo.field_names, uinfo.field_names, tinfo.field_types, uinfo.field_types) |nameT, nameU, TT, TU| {
        if (!std.mem.eql(u8, nameT, nameU)) break .{ nameT, nameU };
        if (@typeInfo(TT) == .@"struct") {
            if (fieldsEql(TT, TU)) |_| break .{ TT, TU };
        } else if (TT != TU) break .{ TT, TU };
    } else null;
    if (value == null) return value;
    switch (@TypeOf(value)) {
        struct { []const u8, []const u8 } => {
            std.testing.failPrint("{s}, {s}", value);
            return .name;
        },
        else => {
            std.testing.failPrint("{}, {}", value);
            return .type;
        },
    }
    return null;
}

test getFieldFlags {
    const T = struct { index: usize, comptime TypeAlias: Alias(type, "value") = .{ .value = usize }, substructure: struct {
        value: usize,
    } };

    const fieldFlags = comptime getFieldFlags(T);
    const targets = [_]Flags{ .leaf, .dissolve, .owned };
    inline for (fieldFlags, targets) |input, target| {
        try std.testing.expectEqual(target, input);
    }
}

test isMetadata {
    // 'format', and 'is valid'
    const Format = struct { []const u8, bool };
    const cases = [_]Format{
        .{ formats.composed, true },
        .{ formats.leaf, true },
        .{ formats.dissolve, true },
        .{ formats.owned, true },
        .{ formats.identity, true },
        .{ pathing.originalSubfield, false },
        .{ pathing.pathSubField, false },
        .{ "", false },
        .{ "__simple_test_case__", false },
    };

    inline for (cases) |value| {
        if (value.@"1")
            try std.testing.expect(isMetadata(value.@"0"))
        else
            try std.testing.expect(!isMetadata(value.@"0"));
    }
}

test OriginalType {
    const types = [_]type{
        struct { u32 },
        struct { index: usize },
        std.mem.Allocator,
        std.ArrayList(usize),
        struct {
            value: u32,
            index: usize,
            substructure: struct { i32 },
        },
        // for fundamental types, we should expect no diff
        f32,
        []const u8,
        []const type,
        [4]type,
        @Vector(5, bool),
    };

    inline for (types) |T| {
        const Pathed = Path(T);
        try std.testing.expect(T == OriginalType(Pathed));
    }
}

test Path {
    const T = struct {
        value: u32,
        substructure: struct {
            doublesub: struct {
                subvalue: usize,
            },
        },
    };

    const Pathed = Path(T);

    // expanded structure.
    const Expected = struct {
        value: u32,
        substructure: struct {
            doublesub: struct {
                subvalue: usize,
                __internal_registry_ownership_path__: PathData("..substructure.doublesub", T),
            },
            __internal_registry_ownership_path__: PathData("..substructure", T),
        },
        __internal_registry_ownership_path__: PathData(".", T),
    };

    try std.testing.expectEqual(null, fieldsEql(Pathed, Expected));
}

test aliasName {
    const names: []const []const u8 = &.{
        "a",
        "b",
        "c",
        "d",
        "",
        "test",
        "another_case",
        "spaces this time",
        "1number",
        " space in front and end ",
        \\a
        \\newline
        ,
        "---------",
    };

    const TestType = void;
    inline for (names) |name| {
        const T = Alias(TestType, name);
        try std.testing.expectEqualStrings(name, comptime aliasName(T));
    }
}

test ApplyMetadata {
    const Case = struct {
        initial: type,
        metadata: []const u8,
        expected: type,
    };

    const cases: []const Case = &.{
        .{
            .initial = struct {},
            .metadata = "test",
            .expected = struct { @"test": void },
        },
        .{
            .initial = struct { u32 },
            .metadata = "null",
            .expected = struct { @"0": u32, null: void },
        },
        .{
            .initial = struct {
                substructure: struct { u32 },
            },
            .metadata = "__internal_registry_leaf_flag__",
            .expected = struct {
                substructure: struct { u32 },
                __internal_registry_leaf_flag__: void,
            },
        },
    };

    inline for (cases) |case| {
        const Outcome = ApplyMetadata(case.initial, case.metadata);
        try std.testing.expectEqual(null, fieldsEql(case.expected, Outcome));
    }
}
